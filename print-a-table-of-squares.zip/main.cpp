# include <iostream>
using namespace std ;

int square (int n)
{
    return n * n ;
}

int main ()
{
    int limit ;
    cout << " How many numbers do you want the square of? " ;
    cin >> limit ;

    cout << " Number \t Square " << endl ;
    cout << " -------------- " << endl ;

    for (int i = 1 ; i <= limit ; i++) {
        cout << i << " \t " << square (i) << endl ;
    }

    return 0 ;
}
